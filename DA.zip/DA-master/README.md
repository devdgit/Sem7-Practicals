# Data Analytics (Laboratory Practice 1)
This repository contains programs written for the course **Data Analysis (LP1)**.
<br>
## Source
* **Iris flower dataset**: https://archive.ics.uci.edu/ml/datasets/Iris
* **Pima Indians Diabetes dataset**: https://data.world/data-society/pima-indians-diabetes-database
* **Twitter Dataset**: https://datahack.analyticsvidhya.com/contest/practice-problem-twitter-sentiment-analysis/
* **BigMart Sales Prediction**: https://datahack.analyticsvidhya.com/contest/practice-problem-bigmart-sales-prediction/